//
//  ViewController.swift
//  TapHealth
//
//  Created by George Ma on 11/7/15.
//  Copyright © 2015 AppGroup. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {
    
    
    @IBOutlet var mapView: MKMapView!
    
    
    var manager: CLLocationManager!
    

    override func viewDidLoad() {
        
        manager = CLLocationManager()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
        
        //set up long tap gesture recognizer
        var gestureLong = UILongPressGestureRecognizer(target: self, action: "addLocation:")
        gestureLong.minimumPressDuration = 2.0
        map.addGestureRecognizer(gestureLong)

    
        super.viewDidLoad()
        
        let initialLocation = CLLocation(latitude: 36.003200, longitude: -78.940147)

        
        let regionRadius: CLLocationDistance = 1000
        func centerMapOnLocation (location: CLLocation) {
            let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius*2.0, regionRadius*2.0)
            mapView.setRegion(coordinateRegion, animated: true)
            
            
        }

        centerMapOnLocation(initialLocation)
        
    }
    
    func addLocation(gestureRecognizer: UIGestureRecognizer){
        //executed once per long press
        if gestureRecognizer.state == UIGestureRecognizerState.Began {
            var touchPoint = gestureRecognizer.locationInView(self.map)
            var newCoordinate = self.map.convertPoint(touchPoint, toCoordinateFromView: self.map)
            var userLocation = CLLocation(latitude: newCoordinate.latitude, longitude: newCoordinate.longitude)
            var title = ""
            CLGeocoder().reverseGeocodeLocation(userLocation, completionHandler: { (placemarks, error) -> Void in
                if((error) != nil){
                    print("error:  \(error)")
                }else{
                    if let p = CLPlacemark(placemark: (placemarks?[0]) as! CLPlacemark) {
                        var mainLocation = ""
                        var subLocation = ""
                        
                        if(p.thoroughfare != nil){
                            mainLocation = p.thoroughfare
                        }
                        
                        if(p.subThoroughfare != nil){
                            subLocation = p.subThoroughfare
                        }
                        title = "\(subLocation) \(mainLocation)"
                    }
                    
                    if title == "" {
                        title = "Added \(NSDate())"
                    }
                    self.savePlace(title, userLocation: userLocation)
                    var annotation = MKPointAnnotation()
                    annotation.coordinate = newCoordinate
                    annotation.title = title
                    self.map.addAnnotation(annotation)
                }
            })
        }
    }
    
    //saves the place to CoreData
    func savePlace(name: String, userLocation: CLLocation) {
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext!
        let place = NSEntityDescription.insertNewObjectForEntityForName("Place",
            inManagedObjectContext: appDelegate.managedObjectContext!) as! Place
        place.name = name
        place.latitude = "\(userLocation.coordinate.latitude)"
        place.longitude = "\(userLocation.coordinate.longitude)"
        var error: NSError?
        if !managedContext.save(error) {
            print("Could not save \(error), \(error?.userInfo)")
        }
    }
    

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

