//
//  reportHealthViewController.swift
//  TapHealth
//
//  Created by George Ma on 11/7/15.
//  Copyright © 2015 AppGroup. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class reportHealthViewController: UIViewController {
    
    @IBAction func reportHealth(sender: AnyObject) {
        
        var recordedTap = MKUserLocation()
        
        
        
        print(recordedTap)
        
    }

    
    var health = 0
    

    override func viewDidLoad() {
        super.viewDidLoad()

   
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
